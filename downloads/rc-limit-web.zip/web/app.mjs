import { initPwa } from './pwa.mjs';
import { t, bindText, initLanguage } from './i18n.mjs';
import { fields, defaults, calibrateRadio, validateDeviceName, validate, validateMappings, profile, nextMapping, Protocol } from './protocol.mjs';
import { openBle } from './ble.mjs';
import { loadBoardProfiles, drawBoard, boardForFirmware } from './boards.mjs';
await initLanguage();
initPwa();
const $ = id => document.getElementById(id);
const controls = {};
const selects = { bidirectional: ['Forward only', 'Bidirectional'], scale: ['Clamp at limit', 'Scale full stick travel'], invert: ['Normal', 'Inverted'] };
for (const [key, label, group] of fields) {
  const wrapper = document.createElement('label');wrapper.append(bindText(document.createTextNode(''), label));
  const input = document.createElement(selects[key] ? 'select' : 'input');
  if (selects[key]) selects[key].forEach((text, value) => input.add(new Option(t(text), value)));
  else { input.type = 'number'; input.step = '1'; input.required = true; }
  input.name = key; input.id = key;
  wrapper.append(input); document.querySelector(`[data-group="${group}"]`).append(wrapper); controls[key] = input;
}
function fill(config) {
  for (const [key, value] of Object.entries(config)) if (controls[key]) controls[key].value = value;
  queueMicrotask(renderBoardGuide);
}
function form() {
  const config = {};
  for (const [key, input] of Object.entries(controls)) {
    if (input.value.trim() === '') throw new Error('Complete every field.');
    config[key] = Number(input.value);
  }
  return validate(config);
}
fill(defaults);
let captures = {}, captureBusy = false, calibrationEpoch = 0;
const capturePositions = ['forward', 'backward', 'neutral'];
function renderCalibration() {
  $('calibration-status').textContent = Object.keys(captures).length ? capturePositions.map(key => t('{position}: {pulse}', { position: t({ forward: 'Full throttle', backward: 'Full backward', neutral: 'Neutral' }[key]), pulse: captures[key] === undefined ? '—' : `${captures[key]} µs` })).join(' · ') : t("Capture all three positions to update this mapping's draft.");
}
function resetCalibration() {
  captures = {}; calibrationEpoch++;
  renderCalibration();
}
function calibrationButtons(connected) {
  $('start-calibration').disabled = !connected || captureBusy;
  $('load-calibration').disabled = !connected || captureBusy;
  for (const position of capturePositions) $('capture-' + position).disabled = !connected || captureBusy;
}
let lastDeviceName, lastDeviceId;
const configurable = data => data?.configurable ?? !data?.armed;
let draftMappings = [{ ...defaults }], loadedMappings = [], selectedMapping = 0, boardName, latestData, protocolVersion = 1;
function stashMapping() { draftMappings[selectedMapping] = form(); }
function renderLoadedCalibration() {
  const c = loadedMappings[selectedMapping];
  $('loaded-calibration').textContent = c ? t('Loaded from board: backward {backward} µs · neutral {neutral} µs · throttle {forward} µs', {
    backward: c.invert ? c.input_max : c.input_min, neutral: c.input_neutral, forward: c.invert ? c.input_min : c.input_max,
  }) : t('This draft mapping has not been loaded from the board.');
}
function renderMappings() {
  resetCalibration();
  $('mapping-select').replaceChildren(...draftMappings.map((c, i) => new Option(`${i + 1}: GPIO${c.input_pin} → GPIO${c.output_pin}`, i)));
  $('mapping-select').value = selectedMapping;
  $('add-mapping').disabled = draftMappings.length >= 4 || !configurable(latestData);
  $('remove-mapping').disabled = draftMappings.length <= 1 || !configurable(latestData);
  fill(draftMappings[selectedMapping]);
  renderLoadedCalibration();
}
function loadMappings(data) {
  loadedMappings = profile(data.mappings ? { version: 2, mappings: data.mappings } : data.config, data.board).mappings.map(c => ({ ...c }));
  draftMappings = loadedMappings.map(c => ({ ...c }));
  selectedMapping = Math.min(selectedMapping, draftMappings.length - 1); renderMappings();
}
function currentProfile() {
  stashMapping(); return { version: 2, mappings: validateMappings(draftMappings, boardName) };
}
renderMappings();
let port, reader, writer, protocol, polling, readTask, bleLink, connecting = false, closing = false, updatingFirmware = false;
let boardProfiles = [], selectedBoard;
function renderBoardGuide() {
  const board = boardProfiles.find(p => p.id === $('board-layout').value); if (!board) return;
  selectedBoard = board;
  $('board-notes').textContent = t(board.notes);
  $('board-source').href = board.source;
  drawBoard(board, $('board-drawing'), Number(controls.input_pin.value), Number(controls.output_pin.value));
  const suggestions = $('pin-suggestions'); suggestions.replaceChildren();
  board.pairs.forEach(([input, output], i) => {
    const button = document.createElement('button'); button.type = 'button';
    button.textContent = t(`${i + 1}: GPIO${input} → GPIO${output}`);
    button.disabled = !configurable(latestData) || (!!boardName && !!protocol && board.firmware !== boardName);
    button.onclick = () => {
      controls.input_pin.value = input; controls.output_pin.value = output; resetCalibration(); renderBoardGuide();
      message('Suggested GPIOs filled into the selected draft mapping. Check all mapping conflicts, then Apply all.');
    }; suggestions.append(button);
  });
}
loadBoardProfiles().then(profiles => {
  boardProfiles = profiles;
  $('board-layout').replaceChildren(...profiles.map(p => new Option(p.name, p.id)));
  const board = latestData ? boardForFirmware(latestData.board, latestData.transports?.usb_interface) : profiles[0];
  $('board-layout').value = board.id; renderBoardGuide();
}).catch(error => { $('board-notes').textContent = error.message; });
$('board-layout').onchange = renderBoardGuide;
for (const key of ['input_pin', 'output_pin']) controls[key].addEventListener('input', renderBoardGuide);
controls.input_pin.addEventListener('input', resetCalibration);
let lastMessage = '';
function message(text) { lastMessage = text || ''; $('message').textContent = t(lastMessage); }
function deviceButtons(connected) {
  calibrationButtons(connected);
  document.querySelectorAll('[data-device]').forEach(b => b.disabled = !connected);
  $('connect').disabled = connected || connecting || updatingFirmware; $('disconnect').disabled = !connected;
  $('connect-ble').disabled = connected || connecting || updatingFirmware;
}
deviceButtons(false);
function status(data) {
  const previousBoard = boardName;
  const supportsNames = typeof data.device_name === 'string' && typeof data.device_id === 'string';
  $('rename-device').disabled = !supportsNames || !configurable(data);
  if (supportsNames) {
    if (lastDeviceId !== data.device_id || $('device-name').value === lastDeviceName || $('device-name').value === data.device_name) $('device-name').value = data.device_name;
    lastDeviceName = data.device_name; lastDeviceId = data.device_id;
    $('device-identity').textContent = t(`${data.device_name} · ${data.board} · ID ${data.device_id}`);
    $('name-note').textContent = t(data.name_pending_restart ? 'Name saved. Restart the board with motor power disconnected to update Bluetooth discovery.' : 'Name is stored on this board and retained by settings-preserving firmware updates.');
  } else { $('device-identity').textContent = t('Upgrade firmware to name this board.'); }
  latestData = data; boardName = data.board; protocolVersion = data.protocol_version || 1;
  $('board').textContent = data.board === 'esp32c3' ? 'ESP32-C3 · USB / BLE serial' : data.board === 'esp32' ? 'ESP32 · USB / Bluetooth SPP' : 'Raspberry Pi Pico · USB serial';
  if (boardProfiles.length && previousBoard !== boardName) $('board-layout').value = boardForFirmware(data.board, data.transports?.usb_interface).id;
  renderBoardGuide();
  $('control-state').textContent = t(data.active ? 'ACTIVE' : data.signal_ok ? 'WAITING FOR NEUTRAL' : 'NO SIGNAL');
  $('signal').textContent = t(data.signal_ok ? 'Receiver signal valid' : 'Receiver lost / invalid');
  const state = data.channel_states ? data.channel_states[selectedMapping] : selectedMapping === 0 ? data : undefined;
  for (const key of ['input', 'output']) {
    $(key).textContent = state ? `${state[`${key}_us`]} µs` : t('Not applied'); $(`${key}-meter`).value = state?.[`${key}_us`] || 800;
  }
  $('saved').textContent = t(data.saved ? 'SAVED' : 'RAM ONLY');
  $('revision').textContent = t(`Revision ${data.revision} · viewing mapping ${selectedMapping + 1}`);
  $('apply').disabled = $('save').disabled = !configurable(data);
  $('add-mapping').disabled = draftMappings.length >= 4 || !configurable(data);
  $('remove-mapping').disabled = draftMappings.length <= 1 || !configurable(data);
  $('transports').textContent = data.transports ? t('USB serial: enabled · Bluetooth serial: {transport}', {transport: data.transports.bluetooth_serial ? t('{name} (enabled{type})', {name: data.transports.bluetooth_name, type: data.transports.bluetooth_type === 'ble' ? ', BLE' : ''}) : t('unavailable')})
    : t(data.board === 'esp32' ? 'USB serial + Bluetooth SPP: RC-Limiter' : 'USB serial enabled · no onboard Bluetooth');
  const summary = $('mapping-summary'); summary.replaceChildren();
  (data.mappings || [data.config]).forEach((c, i) => {
    const s = data.channel_states?.[i] || (i === 0 ? data : {});
    const row = document.createElement('p');
    row.textContent = t(`Live ${i + 1}: GPIO${c.input_pin} → GPIO${c.output_pin} · ${s.input_us} → ${s.output_us} µs · ${t(s.signal_ok ? 'signal OK' : 'signal lost')} · forward ${c.forward_percent}% / reverse ${c.reverse_percent}%`);
    summary.append(row);
  });
  $('pin-hint').textContent = t(data.board === 'esp32c3' ? 'C3 input/output: 0, 1, 3, 4, 5, 6, 7, 10. Keep boot straps, native USB and UART pins free. Default GPIO3 → GPIO4.' : data.board === 'esp32'
    ? 'ESP32 output/input: 18, 19, 21, 22, 23, 25, 26, 27, 32, 33. Extra input-only: 34, 35, 36, 39.'
    : 'Pico input/output: GP0–GP22 and GP26–GP28. GP4 → GP5 by default.');
}
async function activateConnection(current) {
  const data = await current.request('get'); loadMappings(data);
  $('connection').textContent = t('CONNECTED'); $('dot').classList.add('online');
  connecting = false; deviceButtons(true); status(data);
  message('Board mappings loaded. Hold every input at neutral for one second to enable control or change settings.');
  polling = setInterval(() => {
    if (protocol && protocol.pending.size === 0) protocol.request('get').catch(error => message(error.message));
  }, bleLink ? 500 : 250);
}
async function connect() {
  if (updatingFirmware) return;
  if (!navigator.serial) { message('Web Serial is unavailable. Use a supported browser or Electron for USB / Classic serial, or connect a C3 over BLE.'); return; }
  connecting = true; deviceButtons(false);
  try {
    port = await navigator.serial.requestPort({ allowedBluetoothServiceClassIds: ['00001101-0000-1000-8000-00805f9b34fb'] });
    await port.open({ baudRate: 115200, bufferSize: 8192 });
    const vid = port.getInfo?.().usbVendorId;
    const nativeUsb = vid === 0x2e8a || vid === 0x303a;
    try { await port.setSignals({ dataTerminalReady: nativeUsb, requestToSend: false }); } catch { /* Some SPP drivers lack modem signals. */ }
    reader = port.readable.getReader(); writer = port.writable.getWriter();
    protocol = new Protocol(text => writer.write(new TextEncoder().encode(text)), status, error => {
      message(error.message + ' Use transmitter stop or the physical cutoff.'); void disconnect(false);
    });
    const current = protocol;
    readTask = (async () => {
      const decoder = new TextDecoder();
      try {
        while (reader) {
          const { value, done } = await reader.read(); if (done) break;
          current.feed(decoder.decode(value, { stream: true }));
        }
      } catch (error) { if (!closing) message(`Serial connection lost: ${error.message}`); }
      finally { if (!closing && protocol === current) void disconnect(false); }
    })();
    message('Connected. Waiting for board startup…');
    await new Promise(resolve => setTimeout(resolve, 2500));
    if (protocol !== current) return;
    await activateConnection(current);
  } catch (error) {
    message(`Connection failed: ${error.message}`); await disconnect(false);
  } finally { connecting = false; $('connect').disabled = $('connect-ble').disabled = !!protocol; }
}
async function connectBle() {
  if (updatingFirmware) return;
  connecting = true; deviceButtons(false);
  try {
    const link = await openBle(text => protocol?.feed(text), error => { message(error.message); void disconnect(false); });
    bleLink = link;
    writer = { write: bytes => link.write(bytes), releaseLock() {} };
    protocol = new Protocol(text => writer.write(new TextEncoder().encode(text)), status, error => {
      message(error.message + ' Use transmitter stop or physical cutoff.'); void disconnect(false);
    }, 15000);
    await activateConnection(protocol);
  } catch (error) { message(`BLE connection failed: ${error.message}`); await disconnect(false); }
  finally { connecting = false; $('connect').disabled = $('connect-ble').disabled = !!protocol; }
}
async function disconnect(notify = true) {
  if (closing) return;
  closing = true; clearInterval(polling);
  const current = protocol;
  protocol = undefined; current?.close();
  bleLink?.close(); bleLink = undefined;
  try { await reader?.cancel(); await readTask; } catch { /* Device may already be removed. */ }
  reader?.releaseLock(); reader = undefined;
  try { writer?.releaseLock(); await port?.close(); } catch { /* Device may already be removed. */ }
  writer = port = undefined; readTask = undefined;
  $('connection').textContent = t('OFFLINE'); $('dot').classList.remove('online');
  $('control-state').textContent = t('UNKNOWN'); $('signal').textContent = t('No live telemetry');
  $('input').textContent = $('output').textContent = t('—');
  $('mapping-summary').textContent = t('Disconnected; read the board to view live mappings.');
  resetCalibration();
  loadedMappings = [];
  $('calibration-controls').hidden = true;
  $('loaded-calibration').textContent = t('Connect a board to load its receiver calibration.');
  latestData = undefined; lastDeviceName = lastDeviceId = undefined;
  $('device-identity').textContent = t('Disconnected; reconnect to identify the board.');
  $('add-mapping').disabled = draftMappings.length >= 4;
  $('remove-mapping').disabled = draftMappings.length <= 1;
  connecting = closing = false; deviceButtons(false);
  if (notify) message('Disconnected. Receiver control continues independently of the app.');
}
async function action(cmd, extra = {}, load = false) {
  try {
    if (!protocol) throw new Error('Connect a board first.');
    const data = await protocol.request(cmd, extra);
    if (load) loadMappings(data);
    message(({ set_name: data.name_pending_restart ? 'Device name saved. Bluetooth discovery changes after restarting the board.' : 'Device name saved.', set: 'Settings applied to RAM. Save to flash to retain them after power-off.', set_mappings: 'Settings applied to RAM. Save to flash to retain all mappings after power-off.', save: 'Settings saved to board flash.',
      get: 'Board settings loaded into the form.' })[cmd]);
  } catch (error) { message(error.message); }
}
$('start-calibration').onclick = () => {
  resetCalibration();
  $('calibration-controls').hidden = false;
  message('RC transmitter calibration started. Hold each requested position steady before capturing.');
};
$('load-calibration').onclick = () => action('get', {}, true);
for (const position of capturePositions) $('capture-' + position).onclick = async () => {
  if (!protocol || captureBusy) return;
  const current = protocol, mapping = selectedMapping, pin = Number(controls.input_pin.value), epoch = calibrationEpoch;
  captureBusy = true; calibrationButtons(true);
  try {
    const data = await current.request('get');
    if (protocol !== current || mapping !== selectedMapping || pin !== Number(controls.input_pin.value) || epoch !== calibrationEpoch) return;
    const index = data.mappings ? data.mappings.findIndex(c => c.input_pin === pin) : data.config?.input_pin === pin ? 0 : -1;
    if (index < 0) throw new Error('Apply this receiver input GPIO to the board before calibration.');
    const state = data.channel_states ? data.channel_states[index] : index === 0 ? data : undefined;
    const pulse = state?.input_us;
    if (!state?.signal_ok || !Number.isInteger(pulse) || pulse < 800 || pulse > 2200)
      throw new Error('No valid receiver pulse. Check the radio and receiver connection.');
    captures[position] = pulse;
    renderCalibration();
    if (capturePositions.every(key => captures[key] !== undefined)) {
      const config = calibrateRadio(form(), captures);
      fill(config); draftMappings[selectedMapping] = config;
      message('Radio calibration added to draft. Return all inputs to neutral, then Apply all mappings and Save to flash.');
    }
  } catch (error) { message(error.message); }
  finally { captureBusy = false; calibrationButtons(!!protocol); }
};
$('config-form').addEventListener('submit', e => e.preventDefault());
$('connect').onclick = connect;
$('connect-ble').onclick = connectBle;
$('disconnect').onclick = () => disconnect();
$('rename-device').onclick = () => {
  try { void action('set_name', { name: validateDeviceName($('device-name').value) }); } catch (error) { message(error.message); }
};
$('read').onclick = () => action('get', {}, true);
$('apply').onclick = () => {
  try {
    const value = currentProfile();
    if (protocolVersion < 2) {
      if (value.mappings.length !== 1) throw new Error('Upgrade board firmware to use multiple mappings.');
      void action('set', { config: value.mappings[0] }, true);
    } else void action('set_mappings', { mappings: value.mappings }, true);
  } catch (error) { message(error.message); }
};
$('mapping-select').onchange = event => {
  try { stashMapping(); selectedMapping = Number(event.target.value); renderMappings(); if (latestData) status(latestData); }
  catch (error) { event.target.value = selectedMapping; message(error.message); }
};
$('add-mapping').onclick = () => {
  try {
    stashMapping(); draftMappings.push(nextMapping(draftMappings, boardName)); selectedMapping = draftMappings.length - 1;
    renderMappings(); if (latestData) status(latestData); message('Mapping added to draft. Configure it, then Apply all mappings.');
  } catch (error) { message(error.message); }
};
$('remove-mapping').onclick = () => {
  if (draftMappings.length <= 1) return;
  draftMappings.splice(selectedMapping, 1); selectedMapping = Math.min(selectedMapping, draftMappings.length - 1);
  renderMappings(); if (latestData) status(latestData); message('Mapping removed from draft. Apply all mappings to change the board.');
};
$('save').onclick = () => action('save');
$('export').onclick = () => {
  try {
    const blob = new Blob([JSON.stringify(currentProfile(), null, 2) + '\n'], { type: 'application/json' });
    const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = 'rc-limit-profile.json'; link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  } catch (error) { message(error.message); }
};
$('import').onchange = async event => {
  try {
    const file = event.target.files[0]; if (!file) return;
    if (file.size > 8192) throw new Error('Profile is too large.');
    draftMappings = profile(JSON.parse(await file.text()), boardName).mappings.map(c => ({ ...c }));
    selectedMapping = 0; renderMappings(); if (latestData) status(latestData);
    message('Profile imported into form. Apply all mappings to send it to the board.');
  } catch (error) { message(error.message); }
  event.target.value = '';
};
if (window.desktopSerial) {
  window.desktopSerial.onBleDevices(devices => {
    const list = $('ble-list'); list.replaceChildren();
    for (const device of devices) {
      const button = document.createElement('button'); button.textContent = device.deviceName || device.deviceId;
      button.onclick = () => { window.desktopSerial.chooseBle(device.deviceId); $('ble-dialog').close(); }; list.append(button);
    }
    if (!devices.length) list.textContent = t('Scanning for RC-Limiter-C3. Power the board and enable Bluetooth.');
    if (!$('ble-dialog').open) $('ble-dialog').showModal();
  });
  $('cancel-ble').onclick = () => { window.desktopSerial.chooseBle(''); $('ble-dialog').close(); };
  $('ble-dialog').addEventListener('cancel', () => window.desktopSerial.chooseBle(''));
  window.desktopSerial.onPorts(ports => {
    const list = $('port-list'); list.replaceChildren();
    for (const port of ports) {
      const button = document.createElement('button'); button.textContent = t(`${port.displayName || port.portName} (${port.portName})`);
      button.onclick = () => { window.desktopSerial.choose(port.portId); $('port-dialog').close(); }; list.append(button);
    }
    if (!ports.length) list.textContent = t('No ports found. Attach a USB board or pair a Bluetooth serial device.');
    if (!$('port-dialog').open) $('port-dialog').showModal();
  });
  $('cancel-port').onclick = () => { window.desktopSerial.choose(''); $('port-dialog').close(); };
  $('port-dialog').addEventListener('cancel', () => window.desktopSerial.choose(''));
}

let updaterReady = false, updaterLoading = false;
$('firmware-update').addEventListener('toggle', async () => {
  if (!$('firmware-update').open || updaterReady || updaterLoading) return;
  updaterLoading = true;
  try {
    const { initUpdater } = await import('./dist/updater.mjs');
    initUpdater({ canUpdate: () => !protocol && !connecting && !closing,
      setBusy: busy => { updatingFirmware = busy; deviceButtons(!!protocol); } });
    updaterReady = true;
  } catch (error) {
    $('update-status').textContent = 'Updater could not load. For local source checkouts, run npm ci --ignore-scripts and npm run build:web, then reopen this panel. ' + error.message;
  } finally { updaterLoading = false; }
});

window.addEventListener('rc-language-change', () => {
  for (const [key, labels] of Object.entries(selects)) [...controls[key].options].forEach((option, i) => { option.textContent = t(labels[i]); });
  renderCalibration();
  if (latestData) status(latestData);
  else { renderBoardGuide(); $('connection').textContent = t('OFFLINE'); }
  message(lastMessage);
});
