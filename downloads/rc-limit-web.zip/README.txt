RC Limit static web UI

No Node.js installation or build step is needed for this download.
Extract the entire ZIP, then run from the extracted directory:

  python3 -m http.server 8080 --bind 127.0.0.1 --directory web

On Windows, use: py -m http.server 8080 --bind 127.0.0.1 --directory web
Open http://localhost:8080 in desktop Chrome or Edge.

Keep the server running while configuring boards. Do not double-click index.html:
JavaScript modules/device APIs require localhost or HTTPS.
You may also upload web/ to a static HTTPS host of your choice.

USB/Bluetooth availability depends on the browser and OS. Connect devices only
through the explicit device chooser. Firmware flashing requires disconnected
motor power. Read the project's wiring and commissioning instructions first:
https://github.com/shadowroot/rc-limit

This package includes the firmware updater and third-party licenses.
The firmware catalog shows the stable release bundled into this download.
An empty catalog means no stable release was available when it was built.
web/BUILD.json identifies the exact asset contents via SHA-256 checksums.
